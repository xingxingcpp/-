<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文增速榜 > 资料类 > Vim script
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Average daily growth|Updated|
|:-|:-|:-|:-|:-|:-|
|1|[mhinz/vim-galore](https://github.com/mhinz/vim-galore)|:mortar_board: All things Vim!|16462|5|2023-12-22|
|2|[dofy/learn-vim](https://github.com/dofy/learn-vim)|Learning Vim. A Hands-On Tutorial of Vim.|1653|1|2023-11-30|
|3|[kenshin912/Note](https://github.com/kenshin912/Note)|私人笔记|3|0|2024-03-19|
|4|[wsdjeg/ChineseLinter.vim](https://github.com/wsdjeg/ChineseLinter.vim)|中文文档语言规范检查工具|36|0|2024-03-09|
|5|[lymslive/vimllearn](https://github.com/lymslive/vimllearn)|A book for VimL Script language|888|0|2023-12-01|
|6|[MDGSF/MyVim](https://github.com/MDGSF/MyVim)|vim, vimrc, vimrc template, vim document, vim note, vim study, vimtutor, learn vim, vim practice, vim学习, vim笔记, vim训练营, vim教程, vim入门教程, vim简明教程, vim实操教程, vim入门文档, vimtutor中文版|38|0|2024-05-12|
|7|[Jeanhwea/Vim-Tips](https://github.com/Jeanhwea/Vim-Tips)|📝 Vim 编辑器学习笔记|52|0|2024-05-05|
|8|[lhsfcboy/lhsfcboy.github.io](https://github.com/lhsfcboy/lhsfcboy.github.io)|本项目用于创建GitHub的个人主页, 存放配置文件, 代码片段和其他可以公开的资料~|3|0|2024-04-11|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
