<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文增速榜 > 资料类 > Lua
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Average daily growth|Updated|
|:-|:-|:-|:-|:-|:-|
|1|[kawre/leetcode.nvim](https://github.com/kawre/leetcode.nvim)|A Neovim plugin enabling you to solve LeetCode problems.|571|2|2024-05-13|
|2|[Kengxxiao/ArknightsGameData](https://github.com/Kengxxiao/ArknightsGameData)|《明日方舟》游戏数据|1329|1|2024-05-15|
|3|[newObjectccc/newObjectccc.github.io](https://github.com/newObjectccc/newObjectccc.github.io)|一个分享文章和技术还有推荐的Repo~|12|0|2024-05-20|
|4|[JuanZoran/Trans.nvim](https://github.com/JuanZoran/Trans.nvim)|An awesome neovim plugin written by lua which can help translate English into Chinese 一个使用lua编写的neovim英文->中文[离线    在线]翻译插件, 还在施工中|112|0|2024-04-21|
|5|[Yiklek/oh-my-rime](https://github.com/Yiklek/oh-my-rime)|rime 输入法集合|7|0|2024-04-22|
|6|[max-ri/Guidelime](https://github.com/max-ri/Guidelime)|Guidelime: A WoW Classic addon for leveling guides with automatic progress updates|156|0|2024-05-20|
|7|[MsLGXC/GTA-StandAIO](https://github.com/MsLGXC/GTA-StandAIO)|GTAV Stand Mod Menu的All In One多位一体合集储存库,包含了stand的大量优秀脚本、汉化，同时也是MsLGXC线上画质模组的唯一更新地址|27|0|2024-03-04|
|8|[simdsoft/x-studio](https://github.com/simdsoft/x-studio)|This is the issues tracking, roadmap, docs src repo of the x-studio IDE. Copyright © 2014-2024 Simdsoft Limited|116|0|2024-02-10|
|9|[l549349545/MeetingStone_Happy](https://github.com/l549349545/MeetingStone_Happy)|魔兽世界集合石插件修改版|10|0|2024-05-09|
|10|[openresty/lua-resty-lock](https://github.com/openresty/lua-resty-lock)|Simple nonblocking lock API for ngx_lua based on shared memory dictionaries|303|0|2023-11-23|
|11|[LintaoAmons/CoolStuffes](https://github.com/LintaoAmons/CoolStuffes)|我的分享放这里了，大家随便拿去用啊，记得给个星星就行啦～|127|0|2024-03-27|
|12|[LanbingIce/IsaacSocket-Mod](https://github.com/LanbingIce/IsaacSocket-Mod)|这是一个《以撒的结合》的Mod，可为其他mod提供操作剪贴板，连接WebSocket等接口|9|0|2024-03-15|
|13|[k8scat/lua-resty-feishu-auth](https://github.com/k8scat/lua-resty-feishu-auth)|适用于 OpenResty / ngx_lua 的基于飞书组织架构的登录认证|37|0|2024-05-08|
|14|[zincPower/Lua_Study_2022](https://github.com/zincPower/Lua_Study_2022)|用于结合“江澎涌”公众号分享 Lua 知识点，形成知识体系|16|0|2023-11-24|
|15|[generals-space/note-devops](https://github.com/generals-space/note-devops)|linux运维笔记|53|0|2024-05-21|
|16|[mamjun/DST-Sora](https://github.com/mamjun/DST-Sora)|《饥荒：联机版》里 穹妹的mod|7|0|2024-05-12|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
