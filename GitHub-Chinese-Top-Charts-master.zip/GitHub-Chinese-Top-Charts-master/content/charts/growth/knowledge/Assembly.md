<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文增速榜 > 资料类 > Assembly
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Average daily growth|Updated|
|:-|:-|:-|:-|:-|:-|
|1|[Jolsonz/hust_kaoyan](https://github.com/Jolsonz/hust_kaoyan)|本人参与2020华中科技大学研究生考试复试期间所作的一些笔记，主要是数据库和汇编语言的。|52|0|2024-01-11|
|2|[team-s2/summer_course_2023](https://github.com/team-s2/summer_course_2023)|AAA - 2023 短学期安全攻防实践开源仓库（已整合入 ctf_summer_courses）|31|0|2024-05-21|
|3|[Flskying/2023_AT89C51](https://github.com/Flskying/2023_AT89C51)|2023年单片机学习记录|4|0|2023-12-13|
|4|[ZJUIntl-share/zjuintl-icicles](https://github.com/ZJUIntl-share/zjuintl-icicles)|浙大国际校区课程攻略共享计划|11|0|2024-05-20|
|5|[NekoSilverFox/Assembly](https://github.com/NekoSilverFox/Assembly)|⚡ 亲手编写实现基于王爽老师《汇编语言》的300个汇编程序例程   Implementation of 300 assembly program examples based on "Assembly Language" |231|0|2024-02-10|
|6|[Tim-xiaofan/win32asm-learn](https://github.com/Tim-xiaofan/win32asm-learn)|win32汇编语言学习|3|0|2024-05-15|
|7|[web1992/read](https://github.com/web1992/read)|学习笔记 dubbo,rocketmq 源码解析|49|0|2024-05-11|
|8|[dekrt/Reports](https://github.com/dekrt/Reports)|HUST SSE Courses Reports   华科软件学院课程报告|14|0|2024-02-09|
|9|[susudebug/XMU_Assembly](https://github.com/susudebug/XMU_Assembly)|厦门大学信息学院计科汇编资料|3|0|2023-12-22|
|10|[Molotovgirl1/NKUCS_Assembly-Language-and-Reverse-Engineering](https://github.com/Molotovgirl1/NKUCS_Assembly-Language-and-Reverse-Engineering)|南开大学汇编语言与逆向技术课程的作业和代码|4|0|2024-01-21|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
