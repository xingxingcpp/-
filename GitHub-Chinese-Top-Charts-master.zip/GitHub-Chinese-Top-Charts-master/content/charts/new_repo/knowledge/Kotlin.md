<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > Kotlin
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[unit-mesh/build-your-ai-coding-assistant](https://github.com/unit-mesh/build-your-ai-coding-assistant)|有手就会 《构建你自己的 AI 辅助编码助手》 —— 介绍如何 DIY 一个端到端（从 IDE  插件、模型选型、数据集构建到模型微调）的 AI 辅助编程工具，类似于 GitHub Copilot、JetBrains AI Assistant、AutoDev 等。|453|2024-05-21|2023-12-25|
|2|[JIULANG9/WordsFairyNote](https://github.com/JIULANG9/WordsFairyNote)|词仙笔记源码|73|2023-12-30|2023-05-23|
|3|[open-toys-controller/open-DGLAB-controller](https://github.com/open-toys-controller/open-DGLAB-controller)|郊狼3.0 API网络控制器. 支持任意编程语言. 郊狼socket控制器开发教程|33|2024-05-07|2024-03-12|
|4|[WaitFme/BiliBiliAndYou](https://github.com/WaitFme/BiliBiliAndYou)|借鉴学习BiliYou，哔哩等优秀作品。个人学习Compose UI的练习作品|19|2024-03-14|2023-07-17|
|5|[xiaowine/DSP](https://github.com/xiaowine/DSP)|一个SharedPreferences和XSharedPreferences的封装库|9|2024-05-13|2023-09-30|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
