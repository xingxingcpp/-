<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > C++
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[Mq-b/Loser-HomeWork](https://github.com/Mq-b/Loser-HomeWork)|卢瑟们的作业展示，答案讲解，以及一些C++知识|529|2024-05-04|2023-08-03|
|2|[Mq-b/Modern-Cpp-templates-tutorial](https://github.com/Mq-b/Modern-Cpp-templates-tutorial)|现代C++模板教程|382|2024-05-17|2023-12-26|
|3|[youngyangyang04/KVstorageBaseRaft-cpp](https://github.com/youngyangyang04/KVstorageBaseRaft-cpp)|【代码随想录知识星球】项目分享-基于Raft的k-v存储数据库🔥|364|2024-04-07|2023-12-07|
|4|[datawhalechina/smoothly-vslam](https://github.com/datawhalechina/smoothly-vslam)|VSLAM开源基础教程，各章节练习代码|136|2023-11-26|2023-06-05|
|5|[1051727403/SHU-CS-Source-Share](https://github.com/1051727403/SHU-CS-Source-Share)|SHU-上大计算机资料分享汇总❤️❤️❤️|133|2024-05-20|2023-09-07|
|6|[Mq-b/ModernCpp-ConcurrentProgramming-Tutorial](https://github.com/Mq-b/ModernCpp-ConcurrentProgramming-Tutorial)|现代C++并发编程教程|121|2024-05-21|2024-02-28|
|7|[ffengc/Load-balanced-online-OJ-system](https://github.com/ffengc/Load-balanced-online-OJ-system)|Implement an online programming system similar to LeetCode. Multiple compilation service hosts (CR hosts) can be deployed in the background, and then oj_server service will load balance a large number ...|119|2024-05-06|2023-10-20|
|8|[lxiao217/study428](https://github.com/lxiao217/study428)|深度学习、计算机视觉、OpenCV、自动驾驶、SLAM、C++/Python语言开发学习分享|112|2024-05-14|2023-05-29|
|9|[MaaXYZ/MAABH3](https://github.com/MaaXYZ/MAABH3)|《崩坏3》小助手   A one-click tool for the daily tasks of Honkai Impact.|87|2024-02-24|2023-08-04|
|10|[HITerltr/HIT-2022-Fall-Computer-Network](https://github.com/HITerltr/HIT-2022-Fall-Computer-Network)|哈尔滨工业大学2022秋季学期计算机网络课程实验、期末复习与相关MOOC资料|67|2024-03-09|2023-07-30|
|11|[npu-cs/Course-Material](https://github.com/npu-cs/Course-Material)|西工大计算机专业课程攻略   npu-cs/Course-Material|61|2024-01-17|2023-07-19|
|12|[parallel101/simdtutor](https://github.com/parallel101/simdtutor)|x86-64 SIMD矢量优化系列教程|61|2024-01-22|2023-06-16|
|13|[MoonforDream/Data-Structure-and-Algorithms](https://github.com/MoonforDream/Data-Structure-and-Algorithms)|Some data structures and algorithms implemented in C++(数据结构与算法学习笔记C++版)|32|2024-01-09|2024-01-08|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
