<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > Python
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[NanmiCoder/MediaCrawler](https://github.com/NanmiCoder/MediaCrawler)|小红书笔记   评论爬虫、抖音视频   评论爬虫、快手视频   评论爬虫、B 站视频 ｜ 评论爬虫、微博帖子 ｜ 评论爬虫|13818|2024-05-18|2023-06-09|
|2|[LlamaFamily/Llama-Chinese](https://github.com/LlamaFamily/Llama-Chinese)|Llama中文社区，Llama3在线体验和微调模型已开放，实时汇总最新Llama3学习资料，已将所有代码更新适配Llama3，构建最好的中文Llama大模型，完全开源可商用|12146|2024-05-15|2023-07-19|
|3|[modelscope/facechain](https://github.com/modelscope/facechain)|FaceChain is a deep-learning toolchain for generating your Digital-Twin.|8420|2024-04-07|2023-08-10|
|4|[01-ai/Yi](https://github.com/01-ai/Yi)|A series of large language models trained from scratch by developers @01-ai|7267|2024-05-13|2023-11-03|
|5|[jianchang512/pyvideotrans](https://github.com/jianchang512/pyvideotrans)|Translate the video from one language to another and add dubbing.         将视频从一种语言翻译为另一种语言，并添加配音|5900|2024-05-18|2023-10-02|
|6|[JoeanAmier/XHS-Downloader](https://github.com/JoeanAmier/XHS-Downloader)|小红书链接提取/作品采集工具：提取账号发布、收藏、点赞作品链接；提取搜索结果作品、用户链接；采集小红书作品信息；提取小红书作品下载地址；下载小红书无水印作品文件！|4006|2024-04-27|2023-08-16|
|7|[baichuan-inc/Baichuan2](https://github.com/baichuan-inc/Baichuan2)|A series of large language models developed by Baichuan Intelligent Technology|3964|2024-02-26|2023-08-31|
|8|[Fanghua-Yu/SUPIR](https://github.com/Fanghua-Yu/SUPIR)|SUPIR aims at developing Practical Algorithms for Photo-Realistic Image Restoration In the Wild|3553|2024-05-15|2023-12-21|
|9|[AnsonZnl/RehabilitationGuide](https://github.com/AnsonZnl/RehabilitationGuide)|颈椎病腰突康复指南，为程序员群体提供简单可靠的康复指南。|3030|2023-12-25|2023-10-24|
|10|[CrazyBoyM/llama3-Chinese-chat](https://github.com/CrazyBoyM/llama3-Chinese-chat)|Llama3 中文仓库（聚合资料，各种网友及厂商微调、魔改版本有趣权重 & 训练、推理、评测、部署教程视频 & 文档）|2871|2024-05-21|2024-04-18|
|11|[WisdomShell/codeshell](https://github.com/WisdomShell/codeshell)|A series of code large language models developed by PKU-KCL|1569|2024-04-02|2023-09-22|
|12|[SakuraLLM/Sakura-13B-Galgame](https://github.com/SakuraLLM/Sakura-13B-Galgame)|适配轻小说/Galgame的日中翻译大模型|1450|2024-05-15|2023-08-23|
|13|[invictus717/MetaTransformer](https://github.com/invictus717/MetaTransformer)|Meta-Transformer for Unified Multimodal Learning|1448|2023-12-05|2023-07-08|
|14|[NanmiCoder/CrawlerTutorial](https://github.com/NanmiCoder/CrawlerTutorial)|爬虫入门、爬虫进阶、高级爬虫|838|2024-04-25|2024-03-24|
|15|[xd2333/GalTransl](https://github.com/xd2333/GalTransl)|支持GPT-3.5/GPT-4/Newbing/Sakura等大语言模型的Galgame自动化翻译解决方案  Automated translation solution for visual novels supporting GPT-3.5/GPT-4/Newbing/Sakura|797|2024-05-18|2023-05-31|
|16|[jiji262/douyin-downloader](https://github.com/jiji262/douyin-downloader)|抖音批量下载工具，去水印，支持视频、图集、合集、音乐(原声)。免费！免费！免费！|784|2024-05-21|2023-05-25|
|17|[OrionStarAI/Orion](https://github.com/OrionStarAI/Orion)|Orion-14B is a family of models includes a 14B foundation LLM, and a series of models: a chat model, a long context model, a quantized model, a RAG fine-tuned model, and an Agent fine-tuned model. Ori ...|766|2024-04-09|2024-01-17|
|18|[AGI-Edgerunners/LLM-Agents-Papers](https://github.com/AGI-Edgerunners/LLM-Agents-Papers)|A repo lists papers related to LLM based agent|704|2024-05-09|2023-05-31|
|19|[saveweb/review-2023](https://github.com/saveweb/review-2023)|二〇二三年的年终总结都写好了吗？|631|2024-05-13|2023-09-27|
|20|[cv-cat/Spider_XHS](https://github.com/cv-cat/Spider_XHS)|小红书爬虫，小红书笔记、主页、搜索爬取|610|2024-05-17|2023-08-08|
|21|[WangRongsheng/CareGPT](https://github.com/WangRongsheng/CareGPT)|🌞 CareGPT (关怀GPT)是一个医疗大语言模型，同时它集合了数十个公开可用的医疗微调数据集和开放可用的医疗大语言模型，包含LLM的训练、测评、部署等以促进医疗LLM快速发展。Medical LLM, Open Source Driven for a Healthy Future.|543|2024-05-09|2023-08-13|
|22|[morsoli/llm-books](https://github.com/morsoli/llm-books)|利用LLM构建应用实践笔记|539|2024-04-12|2023-06-12|
|23|[CjangCjengh/YakuYaku](https://github.com/CjangCjengh/YakuYaku)|翻译姬：致力于小众领域的机器翻译|531|2024-04-20|2023-08-12|
|24|[codefuse-ai/CodeFuse-DevOps-Model](https://github.com/codefuse-ai/CodeFuse-DevOps-Model)|DevOps-Models is a series of industrial-first LLMs for theDevOps domain. Asking it for any question in the DevOps domain to get solution!|529|2024-01-23|2023-10-30|
|25|[Awesome3DGS/3D-Gaussian-Splatting-Papers](https://github.com/Awesome3DGS/3D-Gaussian-Splatting-Papers)|3D高斯论文列表，每日更新，欢迎大家使用 Discussions 讨论交流|500|2024-05-21|2023-12-20|
|26|[yihong0618/epubhv](https://github.com/yihong0618/epubhv)|Make your epub books vertical or horizontal.|444|2024-01-05|2023-09-04|
|27|[MasterYip/ChatPaper2Xmind](https://github.com/MasterYip/ChatPaper2Xmind)|论文XMind笔记生成工具，将论文pdf通过ChatGPT转换为带有图片和公式的简要XMind笔记，提高论文阅读效率。|422|2024-02-23|2023-07-21|
|28|[jiji262/MediaCrawler-new](https://github.com/jiji262/MediaCrawler-new)|小红书笔记   评论爬虫、抖音视频   评论爬虫、快手视频   评论爬虫、B 站视频 ｜ 评论爬虫、微博帖子 ｜ 评论爬虫|379|2024-04-04|2024-03-20|
|29|[DoiiarX/NLCISBNPlugin](https://github.com/DoiiarX/NLCISBNPlugin)|基于中国国家图书馆ISBN检索的calibre的source/metadata插件|372|2024-02-21|2023-12-14|
|30|[Charmve/OccNet-Course](https://github.com/Charmve/OccNet-Course)|国内首个占据栅格网络全栈课程《从BEV到Occupancy Network，算法原理与工程实践》，包含端侧部署。Surrounding Semantic Occupancy Perception Course for Autonomous Driving (docs,  ppt and source code) 课程主页：http://111.229.117.200:7001/|368|2024-01-13|2023-06-17|
|31|[wpydcr/LLM-Kit](https://github.com/wpydcr/LLM-Kit)|🚀WebUI integrated platform for latest LLMs   各大语言模型的全流程工具 WebUI 整合包。支持主流大模型API接口和开源模型。支持知识库，数据库，角色扮演，mj文生图，LoRA和全参数微调，数据集制作，live2d等全流程应用工具|358|2024-03-21|2023-07-22|
|32|[dreammis/social-auto-upload](https://github.com/dreammis/social-auto-upload)|自动化上传视频到社交媒体：抖音、小红书、视频号、tiktok、youtube、bilibili|304|2024-03-29|2023-12-04|
|33|[zh-plus/openlrc](https://github.com/zh-plus/openlrc)|Transcribe and translate voice into LRC file using Whisper and LLMs (GPT, Claude, et,al). 使用whisper和LLM(GPT，Claude等)来转录、翻译你的音频为字幕文件。|292|2024-04-03|2023-06-08|
|34|[AabyssZG/AWD-Guide](https://github.com/AabyssZG/AWD-Guide)|从零学习AWD比赛指导手册以及AWD脚本整理|288|2023-12-01|2023-10-13|
|35|[jianchang512/ott](https://github.com/jianchang512/ott)|Api tool for local offline text translation supporting multiple languages/支持多语言的本地离线文字翻译api|275|2024-03-30|2024-01-29|
|36|[winninghealth/WiNGPT2](https://github.com/winninghealth/WiNGPT2)|WiNGPT是一个基于GPT的医疗垂直领域大模型，旨在将专业的医学知识、医疗信息、数据融会贯通，为医疗行业提供智能化的医疗问答、诊断支持和医学知识等信息服务，提高诊疗效率和医疗服务质量。|202|2024-04-01|2023-09-26|
|37|[HildaM/sparkdesk-api](https://github.com/HildaM/sparkdesk-api)|讯飞星火大模型 Python api 接口，快捷方便地在 Python 项目中引入星火模型。支持讯飞星火v3.0 v2.0 v1.0。支持接入”星火知识库“|196|2024-04-01|2023-07-04|
|38|[l3yx/jdwp-codeifier](https://github.com/l3yx/jdwp-codeifier)|基于 jdwp-shellifier 的进阶JDWP漏洞利用脚本（动态执行Java/Js代码并获得回显）|177|2023-12-06|2023-11-24|
|39|[mrknow001/API-Explorer](https://github.com/mrknow001/API-Explorer)|API接口管理工具(目前内置微信公众号、微信小程序、企业微信)|177|2024-01-24|2023-07-04|
|40|[Hellohistory/EbookDatabase](https://github.com/Hellohistory/EbookDatabase)|本地网页书籍信息检索|175|2024-02-18|2023-10-01|
|41|[ittuann/Awesome-IntelligentCarRace](https://github.com/ittuann/Awesome-IntelligentCarRace)|智能车竞赛开源项目合集网站✨(恩智浦杯/飞思卡尔杯)   Awesome Intelligent Car Race Website✨(NXP Cup/Freescale Cup)|158|2024-03-11|2023-09-22|
|42|[liuzhao1225/YouDub](https://github.com/liuzhao1225/YouDub)|YouDub是一个开源工具，旨在自动化地将优质的YouTube视频进行翻译和配音，以便将其搬运到中文互联网上。该工具使用了AI语音识别技术将音频转换为文本，然后通过大语言模型将文本翻译成中文，最后通过AI声音克隆技术将中文转换为音频。这样，我们就可以创建出具有原始YouTuber音色的中文配音视频。|145|2024-02-29|2023-11-02|
|43|[Barca0412/Introduction-to-Quantitative-Finance](https://github.com/Barca0412/Introduction-to-Quantitative-Finance)|量化投资学习资料整理：学界（行为金融、投资者情绪、常用程序函数，etc）；业界（公开资料整理，数据源，回测框架，卖方金工研报及复现，量化研究学习路线，etc）|142|2024-02-29|2023-08-04|
|44|[IsshikiHugh/zju-cs-asio](https://github.com/IsshikiHugh/zju-cs-asio)|收集各类与 ZJU-CS 有关的网站形式的资料。|115|2024-01-18|2023-10-17|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
