<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > Go
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[HuanMeng233/weread_downloader](https://github.com/HuanMeng233/weread_downloader)|学习|192|2023-12-20|2023-12-09|
|2|[Foleyzhao/lacerate](https://github.com/Foleyzhao/lacerate)|简单的静态博客生成器|153|2024-03-25|2024-03-12|
|3|[danmuking/DiTing-Go](https://github.com/danmuking/DiTing-Go)|欢迎来到 DiTing！这是一个简单、轻量级的即时通讯（IM）开源项目，采用 Go 编写，严格遵守互联网开发标准。致力于为初学者提供一个友好、易于上手的 IM 解决方案，让你可以轻松入门并开始构建自己的即时通讯应用。|133|2024-05-18|2024-03-30|
|4|[fasnow/idebug](https://github.com/fasnow/idebug)|企业微信、企业飞书接口调用工具。|127|2023-12-19|2023-06-06|
|5|[GuGoOrg/GuGoTik](https://github.com/GuGoOrg/GuGoTik)|第六届字节跳动青训营后端进阶实战项目第一名，迷你抖音后端|104|2024-02-08|2023-07-27|
|6|[logonod/bookmark](https://github.com/logonod/bookmark)|bookmark - 我的书签 基于go实现的在线书签管理工具 支持爬虫、标签、全文检索|73|2023-12-04|2023-05-26|
|7|[ecodeclub/webook](https://github.com/ecodeclub/webook)|一个八股文面试网站，哈哈哈|68|2024-04-01|2023-07-10|
|8|[yusp998/wechat_biz](https://github.com/yusp998/wechat_biz)|微信公众号爬虫，以API方式提供公众号文章获取，包括阅读量、点赞等|65|2023-12-26|2023-12-14|
|9|[FloatTech/NanoBot-Plugin](https://github.com/FloatTech/NanoBot-Plugin)|基于 NanoBot 的 QQ 机器人插件合集|65|2023-12-01|2023-10-15|
|10|[Verthandii/palworld-go](https://github.com/Verthandii/palworld-go)|《幻兽帕鲁》私服启动器|63|2024-02-04|2024-01-25|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
