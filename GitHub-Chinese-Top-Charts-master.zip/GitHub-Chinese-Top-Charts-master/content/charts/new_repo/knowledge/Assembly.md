<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > Assembly
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[team-s2/summer_course_2023](https://github.com/team-s2/summer_course_2023)|AAA - 2023 短学期安全攻防实践开源仓库（已整合入 ctf_summer_courses）|31|2024-05-21|2023-05-24|
|2|[dekrt/Reports](https://github.com/dekrt/Reports)|HUST SSE Courses Reports   华科软件学院课程报告|14|2024-02-09|2023-10-09|
|3|[ZJUIntl-share/zjuintl-icicles](https://github.com/ZJUIntl-share/zjuintl-icicles)|浙大国际校区课程攻略共享计划|11|2024-05-20|2024-01-15|
|4|[Molotovgirl1/NKUCS_Assembly-Language-and-Reverse-Engineering](https://github.com/Molotovgirl1/NKUCS_Assembly-Language-and-Reverse-Engineering)|南开大学汇编语言与逆向技术课程的作业和代码|4|2024-01-21|2024-01-20|
|5|[Flskying/2023_AT89C51](https://github.com/Flskying/2023_AT89C51)|2023年单片机学习记录|4|2023-12-13|2023-08-31|
|6|[susudebug/XMU_Assembly](https://github.com/susudebug/XMU_Assembly)|厦门大学信息学院计科汇编资料|3|2023-12-22|2023-12-22|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
