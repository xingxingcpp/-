<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > C#
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[AIDotNet/AntSK](https://github.com/AIDotNet/AntSK)|基于.Net8+AntBlazor+SemanticKernel 和KernelMemory 打造的AI知识库/智能体，支持本地离线AI大模型。可以不联网离线运行。|785|2024-05-14|2024-02-01|
|2|[ks233/ja-learner](https://github.com/ks233/ja-learner)|📖简易日语学习 / 视觉小说阅读辅助工具|559|2024-03-10|2023-06-02|
|3|[unity3d-jp/Project_TCC](https://github.com/unity3d-jp/Project_TCC)|TCC stands for Tiny Character Controller. TCC is the best way to make your own game. This repository contains all packages and examples for TCC projects.|458|2024-04-30|2024-02-08|
|4|[AIDotNet/fast-wiki](https://github.com/AIDotNet/fast-wiki)|基于.NET8+React+LobeUI实现的企业级智能客服知识库|338|2024-05-18|2024-02-27|
|5|[LeagueTavern/fix-lcu-window](https://github.com/LeagueTavern/fix-lcu-window)|解决《英雄联盟》客户端异常窗口大小的问题。|279|2023-12-13|2023-12-10|
|6|[anjoy8/BCVP.Net8](https://github.com/anjoy8/BCVP.Net8)|ASP.NET8.0入口与实战系列视频教程 配合代码|78|2024-04-15|2023-12-10|
|7|[AtmoOmen/DailyRoutines](https://github.com/AtmoOmen/DailyRoutines)|Dalamud 插件 Daily Routines - 自动化小工具合集|54|2024-05-21|2024-01-14|
|8|[239573049/FastGateway](https://github.com/239573049/FastGateway)|FastGateway 一个超级简单方便的网关，基于Kestrel+Yarp实现的网关。 支持动态配置路由，支持动态配置集群，支持动态配置HTTPS证书，无需重启即可使用。|42|2024-04-03|2024-01-21|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
