<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > Rust
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[cncases/cases](https://github.com/cncases/cases)|中国裁判文书网本地搜索|514|2024-05-20|2024-01-14|
|2|[Borber/Tran](https://github.com/Borber/Tran)|简洁, 快速, 划词翻译|434|2024-05-21|2023-11-09|
|3|[PeiPei233/zju-learning-assistant](https://github.com/PeiPei233/zju-learning-assistant)|帮你快速下载所有课件😋|181|2024-05-15|2023-11-25|
|4|[zeyios/weread-pc](https://github.com/zeyios/weread-pc)|基于pake打包的微信读书项目，优化字体、背景颜色、阅读区域。|51|2024-02-16|2023-11-07|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
