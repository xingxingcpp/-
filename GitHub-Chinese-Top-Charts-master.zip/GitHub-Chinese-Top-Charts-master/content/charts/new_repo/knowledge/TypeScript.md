<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > TypeScript
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[cuixueshe/earthworm](https://github.com/cuixueshe/earthworm)|Learning English through the method of constructing sentences with conjunctions|3324|2024-05-21|2024-01-11|
|2|[cooderl/wewe-rss](https://github.com/cooderl/wewe-rss)|🤗更优雅的微信公众号订阅方式，支持私有化部署、微信公众号RSS生成（基于微信读书）v2.x|3184|2024-05-20|2024-02-27|
|3|[liyupi/sql-mother](https://github.com/liyupi/sql-mother)|免费的闯关式 SQL 自学教程网站，从 0 到 1 带大家掌握常用 SQL 语法，纯前端实现，简单易学~|2868|2024-02-06|2023-08-03|
|4|[Deeptrain-Community/chatnio](https://github.com/Deeptrain-Community/chatnio)|🚀 Next Generation AI One-Stop Internationalization Solution. 🚀 下一代 AI 一站式 B/C 端解决方案，支持 OpenAI，Midjourney，Claude，讯飞星火，Stable Diffusion，DALL·E，ChatGLM，通义千问，腾讯混元，360 智脑，百川 AI，火山方舟，新必应，Gemini，Moonshot 等模型 ...|2514|2024-05-20|2023-07-17|
|5|[meetqy/aspoem](https://github.com/meetqy/aspoem)|Learn Chinese Poetry With AsPoem.com|2198|2024-05-20|2023-12-19|
|6|[revezone/revezone](https://github.com/revezone/revezone)|A lightweight local-first graphic-centric  productivity tool to build your second brain. Supporting Excalidraw/Tldraw whiteboard and notion-like note. 一款以图形为中心、轻量级、本地优先的用于构建第二大脑的效率工具。支持 Excalidraw、Tld ...|1069|2024-01-10|2023-07-07|
|7|[lio-mengxiang/mx-design](https://github.com/lio-mengxiang/mx-design)|最好的react ui组件库教程代码 (The code for the best react component library series tutorial)|786|2024-01-21|2023-07-21|
|8|[latentcat/latentbox](https://github.com/latentcat/latentbox)|A collection of awesome-lists for AI, creativity and art. AI、创意和艺术领域的精选合集。https://latentbox.com|742|2024-05-15|2024-04-05|
|9|[sleepy-zone/fabritor-web](https://github.com/sleepy-zone/fabritor-web)|👻 A creative editor based on fabricjs. 一款基于 fabricjs 的开源创意图片编辑器，旨在让开发者快速构建属于自己的图片编辑器。可应用于海报设计、小红书公众号封面设计、banner 设计等场景。|676|2024-05-21|2023-11-04|
|10|[Yootou-dev/wechat-ai-summarize-bot](https://github.com/Yootou-dev/wechat-ai-summarize-bot)|微信群聊总结助手 JS 版|621|2024-01-10|2023-08-23|
|11|[14790897/paper-ai](https://github.com/14790897/paper-ai)|搜索真实文献并生成引用对应文献的AI论文|612|2024-05-11|2024-01-18|
|12|[yesmore/inke](https://github.com/yesmore/inke)|📖 A WYSIWYG notebook with AI assisted writing and real-time collaboration. Support self hosting.  一个所见即所得的Markdown笔记本，支持AI辅助写作和多人协作，支持自部署，使用IndexedDB存储笔记。|526|2024-02-28|2023-09-26|
|13|[zotero-chinese/zotero-plugins](https://github.com/zotero-chinese/zotero-plugins)|Zotero Plugins Collection   Zotero 插件合集   Awesome Zotero Plugins|304|2024-05-21|2023-09-03|
|14|[lobehub/lobe-chat-agents](https://github.com/lobehub/lobe-chat-agents)|🤖 / 🏪 Agent Index - This is the agent index for LobeChat. It accesses index.json from this repository to display a list of available agents for LobeChat to the agent market.|286|2024-05-21|2023-09-01|
|15|[sancijun/weread-toolbox](https://github.com/sancijun/weread-toolbox)|微信读书工具箱，支持导出图文 Markdown 笔记，同步 Notion 等。|261|2024-05-12|2023-05-30|
|16|[BetaSu/second-curve](https://github.com/BetaSu/second-curve)|程序员第二曲线手册 #副业|155|2024-03-01|2023-12-27|
|17|[1Telescope1/sishi-personal-blog](https://github.com/1Telescope1/sishi-personal-blog)|一个Vue3+Nest的个人博客|144|2024-03-19|2023-07-23|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
