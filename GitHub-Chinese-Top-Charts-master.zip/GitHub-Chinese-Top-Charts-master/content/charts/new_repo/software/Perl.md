<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 软件类 > Perl
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[TheBeastofwar/linuxhacker](https://github.com/TheBeastofwar/linuxhacker)|一款linux 内网渗透辅助工具|47|2024-01-31|2023-11-12|
|2|[YanMing-lxb/YM-VSCode-Configurations-for-LaTeX](https://github.com/YanMing-lxb/YM-VSCode-Configurations-for-LaTeX)|一个可以让你轻松本地部署好LaTeX的项目|7|2024-04-05|2023-07-29|
|3|[Forensax/ExportDeletedFiles](https://github.com/Forensax/ExportDeletedFiles)|基于SleuthKit套件的删除文件恢复工具，支持恢复DD、E01、AFF镜像文件中NTFS系统的已删除文件|2|2024-03-05|2024-03-04|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
