<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文总榜 > 软件类 > Groovy
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|
|:-|:-|:-|:-|:-|
|1|[qq549631030/AndroidJunkCode](https://github.com/qq549631030/AndroidJunkCode)|Android马甲包生成垃圾代码插件|993|2024-03-07|
|2|[ihub-pub/plugins](https://github.com/ihub-pub/plugins)|A set of Gradle plug-ins that greatly simplify project management / 一套极大简化项目管理的Gradle插件集|744|2024-05-21|
|3|[dqzboy/DevOps](https://github.com/dqzboy/DevOps)|DevOps. Make the project development and release simpler, easier and more efficient.|623|2024-05-18|
|4|[galaxybruce/AndroidPionner](https://github.com/galaxybruce/AndroidPionner)|为android工程编译提供常用功能的gradle插件，旨在把一些常用自动化的脚本收集在一起。|39|2024-04-22|
|5|[MystWeb/devops-library](https://github.com/MystWeb/devops-library)|Groovy Pipeline 共享库|12|2024-05-09|
|6|[guolong123/manci](https://github.com/guolong123/manci)|一个 Jenkins library 库，轻松集成实现各个代码平台的 CI/CD 流程|5|2024-05-17|
|7|[YaokunLee/Router](https://github.com/YaokunLee/Router)|自定义路由框架，APT+字节码插桩实现组件自动注册，支持参数解析、路由总表文档生成|3|2024-03-02|
|8|[bwcxyk/config_file](https://github.com/bwcxyk/config_file)|配置文件|3|2024-04-29|
|9|[running-libo/BuildCostPlugin](https://github.com/running-libo/BuildCostPlugin)|编译耗时统计插件|2|2023-11-23|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
