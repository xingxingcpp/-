<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文总榜 > 资料类 > R
<sub>数据更新: 2024-05-22&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|
|:-|:-|:-|:-|:-|
|1|[briatte/awesome-network-analysis](https://github.com/briatte/awesome-network-analysis)|A curated list of awesome network analysis resources.|3406|2024-04-16|
|2|[gesiscss/awesome-computational-social-science](https://github.com/gesiscss/awesome-computational-social-science)|A list of awesome resources for Computational Social Science|467|2024-04-30|
|3|[rpkgs/gg.layers](https://github.com/rpkgs/gg.layers)|ggplot2 extensions 入门|21|2024-05-07|
|4|[Sfeng666/NRA_tax_filing](https://github.com/Sfeng666/NRA_tax_filing)|最新税季 UW-Madison报税指南|14|2024-05-08|
|5|[GShex/Bioinformatics-SanQing-FoZu](https://github.com/GShex/Bioinformatics-SanQing-FoZu)|通过生物信息学分析鉴定与非小细胞肺癌相关关键差异表达基因-论文复现|11|2023-12-12|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
